module.exports = function(grunt) {

  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    typescript: {
      code: {
        src: ['controller/**/*.ts', 'model/**/*.ts', 'spec/**/*.ts'],
        dest: './',
        options: {
          module: 'commonjs',
          sourceMap: true
        }
      }
    },
    concat: {
      options: {
        separator: ';'
      },
      tests: {
        src: ['model/**/*.js', 'spec/*.js'],
        dest: 'spec/integrated/<%= pkg.name %>.spec.js'
      }
    },
    jasmine_node: {
      options: {
        forceExit: true,
        match: '.',
        matchall: false,
        extensions: 'js',
        specNameMatcher: 'spec',
        jUnit: {
          report: true,
          savePath: "./build/reports/jasmine/",
          useDotNotation: true,
          consolidate: true
        }
      },
      all: ['spec/integrated/']
    },
    watch: {
      files: ['controller/**/*.ts', 'model/**/*.ts', 'spec/*.ts'],
      tasks: ['typescript', 'concat', 'jasmine_node']
    }
  });

  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-typescript');
  grunt.loadNpmTasks('grunt-contrib-concat');
  grunt.loadNpmTasks('grunt-jasmine-node');

  grunt.registerTask('default', ['typescript', 'concat', 'jasmine_node']);
};