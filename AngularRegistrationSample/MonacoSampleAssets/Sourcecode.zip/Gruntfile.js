module.exports = function(grunt) {

  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    typescript: {
      base: {
        src: ['scripts/**/*.ts'],
        dest: './',
        options: {
          module: 'commonjs',
          sourceMap: true
        }
      }
    },
    watch: {
      files: ['scripts/**/*.ts'],
      tasks: ['typescript']
    }
  });

  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-typescript');

  grunt.registerTask('default', ['typescript']);
};