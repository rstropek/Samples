module.exports = function(grunt) {

  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    typescript: {
      code: {
        src: ['controller/**/*.ts', 'model/**/*.ts'],
        dest: './',
        options: {
          module: 'commonjs',
          sourceMap: true
        }
      }
    },
    watch: {
      files: ['controller/**/*.ts', 'model/**/*.ts'],
      tasks: ['typescript']
    }
  });

  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-typescript');

  grunt.registerTask('default', ['typescript']);
};